from django.shortcuts import render,get_object_or_404, redirect
from django.contrib.auth import authenticate, login as auth_login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.models import User
from .forms import AppointmentForm, ProfileForm, BookingForm
from .models import Appointment, Offer, Profile
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.forms import UserChangeForm
from .forms import OfferForm

def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            
            return redirect('user_dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'salon/login.html')

def home_view(request):
    return render(request, 'salon/home.html')

def register(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        password = request.POST.get('password')

        if User.objects.filter(username=email).exists():
            messages.error(request, 'Email already in use.')
            return redirect('register')
        
        user = User.objects.create_user(username=email, password=password, first_name=name)
        auth_login(request, user)
        messages.success(request, 'Registration successful!')
        return redirect('login')

    return render(request, 'salon/register.html')

# def admin_login(request):
#     if request.method == 'POST':
#         email = request.POST['email']
#         password = request.POST['password']
#         admin_user = authenticate(request, username=email, password=password)

#         if admin_user is not None and admin_user.is_superuser:
#             # Log in the superuser and redirect to the admin dashboard
#             auth_login(request, admin_user)
#             return redirect('admin_dashboard')
#         else:
#             # Show error message if the user is not a superuser or invalid login
#             return render(request, 'salon/admin_login.html', {'error': 'Invalid admin email or password'})

#     # Render the login page for GET requests
#     return render(request, 'salon/admin_login.html')


def admin_login(request):
    error_message=None
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        admin_user = authenticate(request, username=email, password=password)

        if admin_user is not None and admin_user.is_superuser:
            # auth_login(request, admin_user)
            return redirect('admin_dashboard')
        else:
            error_message="Invalid credentialas"

    return render(request, 'salon/admin_login.html',{'error_message': error_message})


@login_required
def user_dashboard(request):
    return render(request, 'salon/user_dashboard.html')

@login_required
def admin_dashboard(request):
    return render(request, 'salon/admin_dashboard.html')

def about(request):
    return render(request, 'salon/about.html')

def book_appointment(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.user = request.user
            appointment.save()
            return redirect('booking_history')
    else:
        form = BookingForm()
    return render(request, 'salon/appointment.html', {'form': form})

def appointment_success(request):
    return render(request, 'salon/appointment_success.html')

def facial(request):
    return render(request, 'salon/facial.html')

def haircut(request):
    return render(request, 'salon/haircut.html')

def massage(request):
    return render(request, 'salon/massage.html')

def manicure_pedicure(request):
    return render(request, 'salon/manicure_pedicure.html')

def bridal_makeup(request):
    return render(request, 'salon/bridal_makeup.html')

def waxing(request):
    return render(request, 'salon/waxing.html')

def services(request):
    return render(request, 'salon/services.html')

def appointments_view(request):
    if request.user.is_authenticated:
        appointments = Appointment.objects.filter(user=request.user)
    else:
        appointments = []
    return render(request, 'salon/appointments.html', {'appointments': appointments})

def booking_history(request):
    print(f"Authenticated user: {request.user}")  # Debug statement
    past_bookings = Appointment.objects.filter(user=request.user).order_by('-date')
    return render(request, 'salon/booking_history.html', {'bookings': past_bookings})
@login_required
def profile_view(request):
    try:
        profile = request.user.profile
    except Profile.DoesNotExist:
        profile = Profile.objects.create(user=request.user)

    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        avatar = request.FILES.get('avatar')

        request.user.first_name = name
        request.user.username = email
        request.user.save()

        if avatar:
            profile.avatar = avatar
            profile.save()

        messages.success(request, 'Your profile has been updated successfully!')
        return redirect('profile')

    return render(request, 'salon/profile.html', {'profile': profile})

@login_required
def notifications_view(request):
    notifications = []  # Placeholder for notifications
    return render(request, 'salon/notifications.html', {'notifications': notifications})

@login_required
def support_view(request):
    return render(request, 'salon/support.html')

# def exclusive_offers(request):
#     context = {
#         'offers': [
#             {'name': 'Facial Treatment', 'discount': '20% off', 'description': 'Get a glowing skin with our exclusive facial treatments.'},
#             {'name': 'Haircut Special', 'discount': '15% off', 'description': 'Style your hair with our expert stylists.'},
#             {'name': 'Full Body Massage', 'discount': '25% off', 'description': 'Relax and unwind with a soothing massage.'},
#         ]
#     }
#     return render(request, 'salon/exclusive_offers.html', context)


@login_required
def manage_users(request):
    users = User.objects.all()  # Corrected to fetch all users
    context = {'users': users}
    return render(request, 'salon/manage_users.html', context)

def edit_user(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    if request.method == 'POST':
        form = UserChangeForm(request.POST, instance=user)
        if form.is_valid():
            form.save()
            return redirect('manage_users')
    else:
        form = UserChangeForm(instance=user)
    return render(request, 'salon/edit_user.html', {'form': form})

# Delete user
def delete_user(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    if request.method == 'POST':
        user.delete()
        return redirect('manage_users')

@login_required
def manage_offers(request):
    offers = Offer.objects.all()

    # Handle offer addition
    if request.method == 'POST':
        form = OfferForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('manage_offers')  # Redirect to the same page to see the new offer
    else:
        form = OfferForm()

    context = {
        'offers': offers,
        'form': form  # Include the form in the context
    }
    return render(request, 'salon/manage_offers.html', context)
@login_required
def system_settings(request):
    return render(request, 'salon/system_settings.html')

@login_required
def admin_logout(request):
    logout(request)  # Add logout functionality here
    return redirect('admin_login')

def create_user_profile(sender, instance, created, **kwargs):
    if created:
        Profile.objects.create(user=instance)

@receiver(post_save, sender=User)
def save_user_profile(sender, instance, **kwargs):
    instance.profile.save()
    
def manage_appointments(request):
    appointments = Appointment.objects.all().order_by('date', 'time')
    context = {'appointments': appointments}
    return render(request, 'salon/manage_appointments.html', context)

# Accept Appointment View
def accept_appointment(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id)
    if request.method == 'POST':
        appointment.status = 'Accepted'  # Assuming 'Accepted' is one of your status choices
        appointment.save()
        messages.success(request, f"Appointment with {appointment.name} has been accepted.")
    return redirect('manage_appointments')

# Delete Appointment View
def delete_appointment(request, appointment_id):
    appointment = get_object_or_404(Appointment, id=appointment_id)
    if request.method == 'POST':
        appointment.delete()
        messages.success(request, f"Appointment with {appointment.name} has been deleted.")
    return redirect('manage_appointments')

def offer_list(request):
    offers = Offer.objects.all()  # Get all offers (active and inactive)
    
    if request.method == 'POST':
        form = OfferForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('offer_list')  # Redirect to the offer list page after saving
    else:
        form = OfferForm()  # Create a new form for adding an offer

    return render(request, 'salon/offer_list.html', {'offers': offers, 'form': form})

# def offer_list(request):
#     offers = Offer.objects.all()  # Get all offers (active and inactive)

#     # Check if 'edit_offer' or 'delete_offer' is in request to perform specific actions
#     if request.method == 'POST':
#         if 'edit_offer' in request.POST:  # Handle edit action
#             offer_id = request.POST.get('offer_id')  # Get the offer ID
#             offer = get_object_or_404(Offer, id=offer_id)
#             form = OfferForm(request.POST, instance=offer)  # Pass the offer instance to edit
#             if form.is_valid():
#                 form.save()
#                 return redirect('offer_list')

#         elif 'delete_offer' in request.POST:  # Handle delete action
#             offer_id = request.POST.get('offer_id')  # Get the offer ID
#             offer = get_object_or_404(Offer, id=offer_id)
#             offer.delete()  # Delete the offer
#             return redirect('offer_list')

#         else:  # Handle add offer action
#             form = OfferForm(request.POST)
#             if form.is_valid():
#                 form.save()
#                 return redirect('offer_list')
#     else:
#         form = OfferForm()  # Create a new form for adding an offer

#     return render(request, 'salon/offer_list.html', {'offers': offers, 'form': form})